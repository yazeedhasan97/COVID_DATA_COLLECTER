package com.example.covid2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private String NID;
    EditText etNID;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etNID = findViewById(R.id.et_nid);
        btnSubmit = findViewById(R.id.btn_submit);
    }



    public void nextPage(View v) {
        Intent in = new Intent(this, A2.class);
        in.putExtra("NID", NID);
        startActivity(in);
    }
}
